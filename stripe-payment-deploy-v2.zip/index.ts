// Follow this setup guide to integrate the Deno language server with your editor:
// https://deno.land/manual/getting_started/setup_your_environment
// This enables autocomplete, go to definition, etc.

// Setup type definitions for built-in Supabase Runtime APIs
import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// Import Stripe
import Stripe from 'https://esm.sh/stripe@14.21.0?target=deno';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Create service role client for database operations
    // Note: Supabase provides SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY automatically
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );
    
    // Verify critical environment variables
    if (!Deno.env.get('STRIPE_SECRET_KEY')) {
      console.error('[STRIPE-PAYMENT] Missing STRIPE_SECRET_KEY environment variable');
      return new Response(
        JSON.stringify({ error: 'Server configuration error: Missing Stripe key' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const { method } = req;
    
    let body;
    try {
      body = await req.json();
    } catch (error) {
      console.error('[STRIPE-PAYMENT] Failed to parse request body:', error);
      return new Response(
        JSON.stringify({ error: 'Invalid request body', details: error.message }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    const action = body?.action;

    console.log('[STRIPE-PAYMENT] Request:', { method, action, body_keys: Object.keys(body || {}) });

    switch (method) {
      case 'POST':
        if (action === 'create-payment-intent') {
          return await handleCreatePaymentIntent(req, body, supabaseAdmin);
        } else if (action === 'create-checkout-session') {
          return await handleCreateCheckoutSession(req, body, supabaseAdmin);
        } else if (action === 'confirm-payment') {
          return await handleConfirmPayment(req, body, supabaseAdmin);
        } else if (action === 'create-connect-account') {
          return await handleCreateConnectAccount(req, body, supabaseAdmin);
        } else if (action === 'get-connect-account-status' || action === 'get-account-status') {
          return await handleGetConnectAccountStatus(req, body, supabaseAdmin);
        } else if (action === 'verify-connect-account') {
          return await handleVerifyConnectAccount(req, body, supabaseAdmin);
        } else if (action === 'create-onboarding-link') {
          return await handleCreateOnboardingLink(req, body, supabaseAdmin);
        } else if (action === 'transfer-to-connect') {
          return await handleTransferToConnect(req, body, supabaseAdmin);
        } else if (action === 'create-product') {
          return await handleCreateProduct(req, body, supabaseAdmin);
        } else if (action === 'update-product') {
          return await handleUpdateProduct(req, body, supabaseAdmin);
        } else if (action === 'delete-product') {
          return await handleDeleteProduct(req, body, supabaseAdmin);
        } else if (action === 'list-products') {
          return await handleListProducts(req, body, supabaseAdmin);
        } else {
          console.error('[STRIPE-PAYMENT] Unknown action:', action);
          return new Response(
            JSON.stringify({ error: `Unknown action: ${action}` }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
        break;
      
      case 'GET':
        if (action === 'payment-status') {
          return await handleGetPaymentStatus(req, supabaseAdmin);
        } else if (action === 'connect-account-status') {
          return await handleGetConnectAccountStatus(req, supabaseAdmin);
        }
        break;
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('[STRIPE-PAYMENT] Top-level error:', {
      message: error.message,
      type: error.type,
      code: error.code,
      stack: error.stack,
      details: error.toString()
    });
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error',
        details: error.message,
        type: error.type || 'unknown',
        code: error.code || 'unknown'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

async function handleCreatePaymentIntent(req: Request, body: any, supabase: any) {
  try {
    const { amount, currency, payment_type, therapist_id, therapist_connect_account_id, project_id, session_id, idempotency_key, metadata } = body;

    // CRITICAL VALIDATION: Check required fields
    if (!amount || !currency || !therapist_connect_account_id) {
      console.error('[CREATE-PAYMENT] Missing required fields:', { amount, currency, therapist_connect_account_id });
      return new Response(
        JSON.stringify({ 
          error: 'Missing required fields',
          details: {
            hasAmount: !!amount,
            hasCurrency: !!currency,
            hasConnectAccount: !!therapist_connect_account_id
          }
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // CRITICAL VALIDATION: session_id is required for booking payments
    if (!session_id || session_id.trim() === '') {
      console.error('[CREATE-PAYMENT] Missing session_id:', { session_id, payment_type });
      return new Response(
        JSON.stringify({ 
          error: 'Missing required field: session_id',
          details: 'session_id is required for booking payments'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate metadata exists and has required fields
    if (!metadata || typeof metadata !== 'object') {
      return new Response(
        JSON.stringify({ 
          error: 'Missing required metadata',
          details: 'metadata object is required'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!metadata.practitioner_name) {
      return new Response(
        JSON.stringify({ 
          error: 'Missing required metadata',
          details: 'metadata.practitioner_name is required'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!metadata.client_user_id || typeof metadata.client_user_id !== 'string') {
      return new Response(
        JSON.stringify({
          error: 'Missing client user id',
          details: 'metadata.client_user_id is required and must be a string'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const clientUserId = metadata.client_user_id;
    const sessionType = metadata.session_type || 'Session';

    // Initialize Stripe with secret key
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Check for existing payment with same idempotency key
    if (idempotency_key) {
      const { data: existingPayment } = await supabase
        .from('payments')
        .select('*')
        .eq('idempotency_key', idempotency_key)
        .maybeSingle();

      if (existingPayment) {
        console.log('[CREATE-PAYMENT] Found existing payment with idempotency key:', idempotency_key);
        return new Response(
          JSON.stringify({ 
            payment_id: existingPayment.id,
            checkout_url: existingPayment.metadata?.checkout_url,
            checkout_session_id: existingPayment.checkout_session_id,
            status: existingPayment.payment_status
          }),
          { 
            status: 200, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
    }

    // Calculate platform fee: 0.5% flat
    const platformFeeAmount = Math.round(amount * 0.005); // 0.5%
    const practitionerAmount = amount - platformFeeAmount; // Practitioner receives amount minus platform fee

    // Create Stripe Checkout Session instead of Payment Intent with idempotency
    const sessionOptions: any = {
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: currency.toLowerCase(),
          unit_amount: amount,
          product_data: {
            name: `Session with ${metadata.practitioner_name}`,
            description: `${sessionType} on ${metadata.session_date || ''} at ${metadata.session_time || ''}`,
          },
        },
        quantity: 1,
      }],
      payment_intent_data: {
        application_fee_amount: platformFeeAmount,
        transfer_data: {
          destination: therapist_connect_account_id,
          // Note: Stripe automatically calculates transfer amount as (total - application_fee_amount)
          // Do not specify 'amount' here - it's deprecated when using application_fee_amount
        },
        metadata: {
          payment_type: payment_type || 'session_payment',
          therapist_id: therapist_id || '',
          project_id: project_id || '',
          session_id: session_id || '',
          platform_fee_amount: platformFeeAmount,
          practitioner_amount: practitionerAmount,
          ...metadata
        }
      },
      customer_email: metadata.client_email,
      success_url: `${Deno.env.get('APP_URL')}/booking-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${Deno.env.get('APP_URL')}/marketplace`,
      metadata: { 
        session_id: session_id, // Required - validated above
        therapist_id: therapist_id || '',
        client_user_id: metadata.client_user_id, // Ensure this is always included
        client_email: metadata.client_email, // Ensure this is always included
        client_name: metadata.client_name || '',
        session_date: metadata.session_date || '',
        session_time: metadata.session_time || '',
        session_type: metadata.session_type || 'Session',
        practitioner_name: metadata.practitioner_name || '',
        ...metadata 
      }
    };

    // Create Checkout Session, supplying idempotency key via Stripe request options (not in payload)
    const session = await stripe.checkout.sessions.create(
      sessionOptions,
      idempotency_key ? { idempotencyKey: idempotency_key } : undefined
    );

    // Store payment record in database with idempotency key
    const { data: payment, error } = await supabase
      .from('payments')
      .insert({
        stripe_payment_intent_id: session.payment_intent,
        checkout_session_id: session.id,
        amount: amount, // Total amount paid by client
        platform_fee_amount: platformFeeAmount, // Platform fee deducted
        practitioner_amount: practitionerAmount, // Amount practitioner receives
        currency: currency.toLowerCase(),
        payment_status: 'pending',
        payment_type: payment_type,
        user_id: clientUserId,
        therapist_id: therapist_id,
        project_id: project_id,
        session_id: session_id,
        idempotency_key: idempotency_key,
        metadata: {
          ...metadata,
          checkout_url: session.url,
          idempotency_key: idempotency_key
        }
      })
      .select()
      .single();

    if (error) throw error;

    return new Response(
      JSON.stringify({ 
        payment_id: payment.id,
        checkout_url: session.url,
        checkout_session_id: session.id,
        status: session.payment_status
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error: any) {
    console.error('[CREATE-PAYMENT] Error creating checkout session:', error);
    console.error('[CREATE-PAYMENT] Error details:', {
      message: error?.message,
      type: error?.type,
      code: error?.code,
      param: error?.param,
      statusCode: error?.statusCode
    });
    
    // Return specific error message
    let errorMessage = 'Failed to create checkout session';
    if (error?.message?.includes('account')) {
      errorMessage = 'Invalid or restricted Stripe Connect account';
    } else if (error?.type === 'StripeInvalidRequestError') {
      errorMessage = `Stripe error: ${error.message}`;
    }
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        details: error?.message,
        stripeError: error?.type
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function handleConfirmPayment(req: Request, body: any, supabase: any) {
  try {
    const { payment_intent_id } = body;

    // Initialize Stripe with secret key
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Retrieve payment intent from Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(payment_intent_id);

    // Update payment status based on Stripe status
    const { error } = await supabase
      .from('payments')
      .update({ 
        payment_status: paymentIntent.status === 'succeeded' ? 'succeeded' : paymentIntent.status,
        stripe_response: paymentIntent
      })
      .eq('stripe_payment_intent_id', payment_intent_id);

    if (error) throw error;

    return new Response(
      JSON.stringify({ 
        status: paymentIntent.status,
        amount: paymentIntent.amount,
        currency: paymentIntent.currency,
        payment_method: paymentIntent.payment_method
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error confirming payment:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to confirm payment' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleCreateConnectAccount(req: Request, body: any, supabase: any) {
  // Extract return_url from body if provided (for profile/subscription pages)
  const returnUrl = body?.return_url || null;
  try {
    const { userId, email, firstName, lastName, businessType } = body;
    
    console.log('[CREATE-CONNECT] Starting with params:', { userId, email, firstName, lastName, businessType });

    // Resolve authenticated user using anon key client
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('[CREATE-CONNECT] Missing authorization header');
      return new Response(
        JSON.stringify({ error: 'Unauthorized: missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Create anon key client for user validation
    const supabaseAnon = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const token = authHeader.replace('Bearer ', '');
    const { data, error: authError } = await supabaseAnon.auth.getUser(token);
    
    if (authError || !data?.user?.id) {
      console.error('[CREATE-CONNECT] Auth error:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized: invalid user', details: authError?.message }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }
    
    const authenticatedUserId = data.user.id;

    // IDEMPOTENCY CHECK: Check if user already has a Connect account
    const { data: existingAccount, error: fetchError } = await supabase
      .from('connect_accounts')
      .select('*')
      .eq('user_id', authenticatedUserId)
      .maybeSingle();

    if (fetchError) {
      console.error('[CREATE-CONNECT] Error checking existing account:', fetchError);
    }

    let accountId: string;
    let connectAccount: any;

    if (existingAccount && existingAccount.stripe_account_id) {
      // Account already exists - return existing onboarding link (idempotent)
      console.log('[CREATE-CONNECT] Existing account found:', existingAccount.stripe_account_id);
      accountId = existingAccount.stripe_account_id;
      connectAccount = existingAccount;

      // Check if account needs onboarding
      const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
        apiVersion: '2023-10-16',
      });

      const account = await stripe.accounts.retrieve(accountId);
      
      // If fully onboarded, don't create new link
      if (account.charges_enabled && account.payouts_enabled && account.details_submitted) {
        return new Response(
          JSON.stringify({ 
            connect_account_id: connectAccount.id,
            stripe_account_id: accountId,
            status: 'active',
            onboardingUrl: null,
            message: 'Account already fully onboarded'
          }),
          { 
            status: 200, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
    } else {
      // Initialize Stripe with secret key
      const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
        apiVersion: '2023-10-16',
      });

      // Create NEW Stripe Connect account
      const account = await stripe.accounts.create({
        type: 'express',
        country: 'GB',
        email: email,
        business_type: businessType || 'individual',
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
      });

      accountId = account.id;
      console.log('[CREATE-CONNECT] Created Stripe account:', accountId);

      // Store connect account record
      const { data: newConnectAccount, error: dbError } = await supabase
        .from('connect_accounts')
        .insert({
          stripe_account_id: accountId,
          user_id: authenticatedUserId,
          account_status: 'pending',
          business_type: businessType || 'individual',
          charges_enabled: false,
          payouts_enabled: false,
          details_submitted: false
        })
        .select()
        .single();

      if (dbError) {
        console.error('[CREATE-CONNECT] Database error:', dbError);
        // If duplicate key error, account was created between check and insert
        if (dbError.code === '23505') {
          // Fetch the existing account
          const { data: recovered } = await supabase
            .from('connect_accounts')
            .select('*')
            .eq('stripe_account_id', accountId)
            .single();
          connectAccount = recovered;
          accountId = recovered?.stripe_account_id || accountId;
        } else {
          throw dbError;
        }
      } else {
        connectAccount = newConnectAccount;
      }

      console.log('[CREATE-CONNECT] Saved to database:', connectAccount.id);
    }

    // Initialize Stripe for account link creation
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Create account link for onboarding (works for new and existing accounts)
    // Use provided return_url if available (from profile/subscription), otherwise default to onboarding
    const baseUrl = Deno.env.get('APP_URL') || '';
    const defaultReturnUrl = `${baseUrl}/onboarding/stripe-return`;
    const defaultRefreshUrl = `${baseUrl}/onboarding/stripe-return?refresh=true`;
    
    // If return_url is provided (from profile/subscription), route through StripeReturn with return_url param
    // Otherwise use default onboarding return URL
    let finalReturnUrl: string;
    let finalRefreshUrl: string;
    
    if (returnUrl) {
      // User came from profile/subscription - route through StripeReturn with return_url param
      finalReturnUrl = `${baseUrl}/onboarding/stripe-return?return_url=${encodeURIComponent(returnUrl)}`;
      finalRefreshUrl = `${baseUrl}/onboarding/stripe-return?return_url=${encodeURIComponent(returnUrl)}&refresh=true`;
    } else {
      // User came from onboarding - use default
      finalReturnUrl = defaultReturnUrl;
      finalRefreshUrl = defaultRefreshUrl;
    }
    
    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: finalRefreshUrl,
      return_url: finalReturnUrl,
      type: 'account_onboarding',
    });

    console.log('[CREATE-CONNECT] Created account link:', accountLink.url);

    return new Response(
      JSON.stringify({ 
        connect_account_id: connectAccount.id,
        stripe_account_id: accountId,
        status: connectAccount.account_status || 'pending',
        onboardingUrl: accountLink.url
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('[CREATE-CONNECT] Error details:', {
      message: error.message,
      type: error.type,
      code: error.code,
      details: error.toString()
    });
    return new Response(
      JSON.stringify({ 
        error: 'Failed to create connect account', 
        details: error.message,
        type: error.type || 'unknown',
        code: error.code || 'unknown'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleTransferToConnect(req: Request, body: any, supabase: any) {
  try {
    const { amount, currency, connect_account_id, payment_intent_id } = body;

    // Initialize Stripe with secret key
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Create transfer to Connect account
    const transfer = await stripe.transfers.create({
      amount: amount, // Amount in pence
      currency: currency.toLowerCase(),
      destination: connect_account_id,
      transfer_group: payment_intent_id ? `payment_${payment_intent_id}` : undefined,
      metadata: {
        payment_intent_id: payment_intent_id || '',
        therapist_id: connect_account_id,
      }
    });

    // Resolve authenticated user
    let userId: string | null = null;
    try {
      const authHeader = req.headers.get('Authorization');
      if (authHeader) {
        const token = authHeader.replace('Bearer ', '');
        const { data } = await supabase.auth.getUser(token);
        userId = data?.user?.id ?? null;
      }
    } catch (_) {
      userId = null;
    }

    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized: missing or invalid user' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Store transfer record
    const { data: transferRecord, error } = await supabase
      .from('payouts')
      .insert({
        stripe_transfer_id: transfer.id,
        therapist_id: userId,
        amount: amount,
        currency: currency.toLowerCase(),
        payout_status: transfer.status === 'paid' ? 'succeeded' : 'pending',
        connect_account_id: connect_account_id,
        payment_intent_id: payment_intent_id
      })
      .select()
      .single();

    if (error) throw error;

    return new Response(
      JSON.stringify({ 
        transfer_id: transferRecord.id,
        stripe_transfer_id: transfer.id,
        status: transfer.status,
        amount: transfer.amount,
        currency: transfer.currency
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error creating transfer:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to create transfer' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleGetPaymentStatus(req: Request, supabase: any) {
  try {
    const url = new URL(req.url);
    const paymentId = url.searchParams.get('payment_id');

    if (!paymentId) {
      return new Response(
        JSON.stringify({ error: 'Payment ID required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const { data: payment, error } = await supabase
      .from('payments')
      .select('*')
      .eq('id', paymentId)
      .single();

    if (error) throw error;

    return new Response(
      JSON.stringify({ 
        payment_id: payment.id,
        status: payment.payment_status,
        amount: payment.amount,
        currency: payment.currency
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error getting payment status:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to get payment status' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleGetConnectAccountStatus(req: Request, body: any, supabase: any) {
  try {
    const { userId, user_id, account_id } = body;
    const actualUserId = userId || user_id;
    const actualAccountId = account_id;

    // If account_id is provided, get user from that
    let targetUserId = actualUserId;
    let stripeAccountId = actualAccountId;

    if (actualAccountId && !actualUserId) {
      // Look up user by account_id
      const { data: accountUser, error: lookupError } = await supabase
        .from('users')
        .select('id, stripe_connect_account_id')
        .eq('stripe_connect_account_id', actualAccountId)
        .single();
      
      if (!lookupError && accountUser) {
        targetUserId = accountUser.id;
        stripeAccountId = accountUser.stripe_connect_account_id;
      }
    }

    if (!targetUserId && !stripeAccountId) {
      return new Response(
        JSON.stringify({ error: 'User ID or Account ID required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get connect account from database or users table
    const { data: user, error: userError } = await supabase
      .from('users')
      .select('stripe_connect_account_id')
      .eq('id', targetUserId || actualUserId)
      .single();
    
    if (userError || !user?.stripe_connect_account_id) {
      return new Response(
        JSON.stringify({ error: 'No Stripe account found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const finalAccountId = user.stripe_connect_account_id || stripeAccountId;
    const finalUserId = targetUserId || actualUserId;

    if (!finalAccountId) {
      console.error('[CONNECT-STATUS] No account ID available');
      return new Response(
        JSON.stringify({ error: 'No Stripe account ID found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Initialize Stripe first - this is the source of truth
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Try to retrieve account from Stripe (will fail if invalid)
    let account;
    try {
      account = await stripe.accounts.retrieve(finalAccountId);
    } catch (stripeError: any) {
      console.error('[CONNECT-STATUS] Stripe API error:', stripeError);
      return new Response(
        JSON.stringify({ 
          error: 'Stripe account not found or invalid',
          details: stripeError.message
        }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Now check/update database record
    // CRITICAL: Query by stripe_account_id first (exact match) to avoid duplicate issues
    let connectAccount;
    let queryMethod = 'none';
    
    if (finalAccountId) {
      console.log('[CONNECT-STATUS] Querying by stripe_account_id:', finalAccountId);
      const { data: matchedAccounts, error: accountError } = await supabase
        .from('connect_accounts')
        .select('*')
        .eq('stripe_account_id', finalAccountId)
        .limit(1);
      
      if (accountError) {
        console.error('[CONNECT-STATUS] Error querying by stripe_account_id:', accountError);
      } else if (matchedAccounts && matchedAccounts.length > 0) {
        connectAccount = matchedAccounts[0];
        queryMethod = 'stripe_account_id';
        console.log('[CONNECT-STATUS] Found record by stripe_account_id:', connectAccount.id);
      }
    }

    // Fallback: query by user_id if no match found by stripe_account_id
    if (!connectAccount && finalUserId) {
      console.log('[CONNECT-STATUS] Fallback: Querying by user_id:', finalUserId);
      const { data: userAccounts, error: userError } = await supabase
        .from('connect_accounts')
        .select('*')
        .eq('user_id', finalUserId)
        .order('created_at', { ascending: false })
        .limit(1);
      
      if (userError) {
        console.error('[CONNECT-STATUS] Error querying by user_id:', userError);
      } else if (userAccounts && userAccounts.length > 0) {
        connectAccount = userAccounts[0];
        queryMethod = 'user_id';
        console.log('[CONNECT-STATUS] Found record by user_id:', connectAccount.id);
        
        // Warn if multiple records exist for this user
        const { count, error: countError } = await supabase
          .from('connect_accounts')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', finalUserId);
        
        if (!countError && count && count > 1) {
          console.warn(`[CONNECT-STATUS] WARNING: User has ${count} connect_accounts records. Using most recent.`);
          console.warn(`[CONNECT-STATUS] User's stripe_connect_account_id: ${finalAccountId}, Selected record: ${connectAccount.stripe_account_id}`);
        }
      }
    }

    // If connect_accounts record doesn't exist, create it
    let finalAccount = connectAccount;
    if (!connectAccount) {
      console.log('[CONNECT-STATUS] Creating missing connect_accounts record');
      const { data: newRecord, error: insertError } = await supabase
        .from('connect_accounts')
        .insert({
          user_id: finalUserId,
          stripe_account_id: finalAccountId,
          account_status: account.charges_enabled && account.payouts_enabled && account.details_submitted ? 'active' : 'pending',
          charges_enabled: account.charges_enabled,
          payouts_enabled: account.payouts_enabled,
          details_submitted: account.details_submitted,
          business_type: account.business_type || 'individual',
          country: account.country || 'GB',
          email: account.email
        })
        .select()
        .single();

      if (insertError) {
        console.error('[CONNECT-STATUS] Failed to create record:', insertError);
        // Continue anyway - use Stripe data directly
      } else {
        finalAccount = newRecord;
      }
    }

    console.log('[CONNECT-STATUS] Retrieved from Stripe:', {
      id: account.id,
      charges_enabled: account.charges_enabled,
      payouts_enabled: account.payouts_enabled,
      details_submitted: account.details_submitted
    });
    
    console.log('[CONNECT-STATUS] Query method used:', queryMethod);
    console.log('[CONNECT-STATUS] Database record found:', !!finalAccount);
    if (finalAccount) {
      console.log('[CONNECT-STATUS] Database record ID:', finalAccount.id);
      console.log('[CONNECT-STATUS] Database stripe_account_id:', finalAccount.stripe_account_id);
    }

    // Update database with latest status if record exists
    if (finalAccount) {
      const { data: updatedAccount, error: updateError } = await supabase
        .from('connect_accounts')
        .update({
          account_status: account.charges_enabled && account.payouts_enabled && account.details_submitted ? 'active' : 'pending',
          charges_enabled: account.charges_enabled,
          payouts_enabled: account.payouts_enabled,
          details_submitted: account.details_submitted,
          updated_at: new Date().toISOString()
        })
        .eq('id', finalAccount.id)
        .select()
        .single();

      if (updateError) {
        console.error('[CONNECT-STATUS] Update error:', updateError);
      } else if (updatedAccount) {
        finalAccount = updatedAccount;
      }

      // Ensure users table is also updated (trigger should handle this, but safety net)
      await supabase
        .from('users')
        .update({ stripe_connect_account_id: finalAccountId })
        .eq('id', finalUserId)
        .neq('stripe_connect_account_id', finalAccountId); // Only update if different
    }

    // Return with camelCase keys to match frontend expectations
    // Use Stripe data as source of truth (always up-to-date)
    const statusValue = finalAccount?.account_status || 
      (account.charges_enabled && account.payouts_enabled && account.details_submitted ? 'active' : 'pending');
    
    return new Response(
      JSON.stringify({ 
        connect_account_id: finalAccount?.id || null,
        stripe_account_id: finalAccountId,
        status: statusValue,
        chargesEnabled: account.charges_enabled || false,
        payoutsEnabled: account.payouts_enabled || false,
        detailsSubmitted: account.details_submitted || false,
        requirementsCurrentlyDue: account.requirements?.currently_due || [],
        isFullyOnboarded: (account.charges_enabled && account.payouts_enabled && account.details_submitted) || false
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error getting connect account status:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to get connect account status', details: error.message }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleVerifyConnectAccount(req: Request, body: any, supabase: any) {
  try {
    const { therapist_connect_account_id, practitioner_id, user_id } = body;
    const targetAccountId = therapist_connect_account_id;
    const targetUserId = practitioner_id || user_id;

    // Enhanced logging to see what was received
    console.log('[VERIFY-CONNECT-ACCOUNT] Received parameters:', {
      therapist_connect_account_id: targetAccountId,
      practitioner_id,
      user_id,
      targetAccountId,
      targetUserId,
      hasAccountId: !!targetAccountId,
      hasUserId: !!targetUserId,
      accountIdType: typeof targetAccountId,
      userIdType: typeof targetUserId
    });

    if (!targetAccountId && !targetUserId) {
      const errorResponse = {
        error: 'Missing connect_account_id or user_id',
        received: {
          therapist_connect_account_id: targetAccountId,
          practitioner_id,
          user_id,
          body_keys: Object.keys(body || {})
        },
        message: 'Either therapist_connect_account_id or practitioner_id/user_id must be provided'
      };
      
      console.error('[VERIFY-CONNECT-ACCOUNT] Validation failed:', errorResponse);
      
      return new Response(
        JSON.stringify(errorResponse),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Get account ID from database if not provided
    let finalAccountId = targetAccountId;
    if (!finalAccountId && targetUserId) {
      const { data: connectAccount } = await supabase
        .from('connect_accounts')
        .select('stripe_account_id')
        .eq('user_id', targetUserId)
        .eq('account_status', 'active')
        .maybeSingle();
      
      if (!connectAccount?.stripe_account_id) {
        return new Response(
          JSON.stringify({ 
            verified: false,
            error: 'No active Stripe Connect account found',
            charges_enabled: false,
            payouts_enabled: false,
            details_submitted: false
          }),
          { 
            status: 200, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }
      finalAccountId = connectAccount.stripe_account_id;
    }

    // Verify account status directly from Stripe API
    try {
      const account = await stripe.accounts.retrieve(finalAccountId);
      
      const isReady = account.charges_enabled && account.payouts_enabled && account.details_submitted;
      
      return new Response(
        JSON.stringify({
          verified: isReady,
          charges_enabled: account.charges_enabled || false,
          payouts_enabled: account.payouts_enabled || false,
          details_submitted: account.details_submitted || false,
          account_id: finalAccountId,
          capabilities: account.capabilities || {},
          requirements: account.requirements || {}
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    } catch (stripeError: any) {
      console.error('[VERIFY-CONNECT-ACCOUNT] Stripe API error:', stripeError);
      return new Response(
        JSON.stringify({ 
          verified: false,
          error: 'Stripe account not found or invalid',
          details: stripeError.message,
          charges_enabled: false,
          payouts_enabled: false,
          details_submitted: false
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
  } catch (error: any) {
    console.error('[VERIFY-CONNECT-ACCOUNT] Error:', error);
    return new Response(
      JSON.stringify({ 
        verified: false,
        error: 'Failed to verify Connect account',
        details: error.message
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleCreateOnboardingLink(req: Request, body: any, supabase: any) {
  // UNIFIED APPROACH: This now calls the same unified logic as handleCreateConnectAccount
  // Just normalize the parameters and delegate
  try {
    const { user_id, email, first_name, last_name, return_url } = body;
    
    // Normalize parameter names to match handleCreateConnectAccount
    const normalizedBody = {
      userId: user_id,
      email: email,
      firstName: first_name,
      lastName: last_name,
      businessType: 'individual',
      return_url: return_url // Pass through return_url
    };

    // Delegate to unified function
    return await handleCreateConnectAccount(req, normalizedBody, supabase);
  } catch (error) {
    console.error('[CREATE-ONBOARDING-LINK] Error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Failed to create onboarding link', 
        details: error.message,
        type: error.type || 'unknown',
        code: error.code || 'unknown'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

async function handleCreateCheckoutSession(req: Request, body: any, supabase: any) {
  try {
    console.log('[CREATE-CHECKOUT-SESSION] Starting function');
    
    const { practitioner_id, price_id, client_email, client_name } = body;
    console.log('[CREATE-CHECKOUT-SESSION] Request data:', { practitioner_id, price_id, client_email, client_name });

    if (!practitioner_id || !price_id) {
      console.log('[CREATE-CHECKOUT-SESSION] Missing required fields');
      return new Response(
        JSON.stringify({ error: 'Missing required fields: practitioner_id, price_id' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Verify user authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.log('[CREATE-CHECKOUT-SESSION] Missing auth header');
      return new Response(
        JSON.stringify({ error: 'Unauthorized: missing authorization header' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Create anon key client for user validation
    const supabaseAnon = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const token = authHeader.replace('Bearer ', '');
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);
    
    if (authError || !authData?.user?.id) {
      console.log('[CREATE-CHECKOUT-SESSION] Auth error:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized: invalid user' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log('[CREATE-CHECKOUT-SESSION] Authentication successful');

    // Initialize Stripe with secret key
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    });

    // Generate idempotency key
    const idempotencyKey = `checkout_${practitioner_id}_${client_email}_${Date.now()}`;
    console.log('[CREATE-CHECKOUT-SESSION] Idempotency key:', idempotencyKey);

    // Check if session already exists (idempotency check)
    const { data: existingSession, error: existingError } = await supabase
      .from('checkout_sessions')
      .select('stripe_checkout_session_id, status')
      .eq('idempotency_key', idempotencyKey)
      .gte('created_at', new Date(Date.now() - 3600000).toISOString()) // Last hour
      .maybeSingle();

    if (existingSession && existingSession.status === 'completed') {
      console.log('[CREATE-CHECKOUT-SESSION] Found existing completed session');
      return new Response(
        JSON.stringify({ 
          checkout_url: `https://checkout.stripe.com/c/pay/${existingSession.stripe_checkout_session_id}`,
          existing: true 
        }),
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get practitioner's Stripe Connect account
    const { data: practitioner, error: practitionerError } = await supabase
      .from('users')
      .select('stripe_connect_account_id, first_name, last_name')
      .eq('id', practitioner_id)
      .single();

    if (practitionerError || !practitioner?.stripe_connect_account_id) {
      console.log('[CREATE-CHECKOUT-SESSION] Practitioner not found or not connected:', practitionerError);
      return new Response(
        JSON.stringify({ error: 'Practitioner not connected to Stripe' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get product details
    const { data: product, error: productError } = await supabase
      .from('practitioner_products')
      .select('*')
      .eq('stripe_price_id', price_id)
      .eq('is_active', true)
      .single();

    if (productError || !product) {
      console.log('[CREATE-CHECKOUT-SESSION] Product not found:', productError);
      return new Response(
        JSON.stringify({ error: 'Product not found or inactive' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Calculate application fee (0.5% platform fee)
    const applicationFeeAmount = Math.round(product.price_amount * 0.005);
    
    console.log('[CREATE-CHECKOUT-SESSION] Creating checkout session:', {
      price_id,
      application_fee: applicationFeeAmount,
      destination: practitioner.stripe_connect_account_id,
      product_price: product.price_amount
    });

    // CRITICAL FIX: Use price_data instead of price because prices are created on Connect account
    // but checkout sessions with transfer_data need prices on platform account
    // Create checkout session with application fee using inline price_data
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'gbp',
            unit_amount: product.price_amount, // Price in pence
            product_data: {
              name: product.name,
              description: product.description || undefined,
              metadata: {
                practitioner_id: practitioner_id,
                product_id: product.id,
                original_price_id: price_id, // Keep reference to original
              },
            },
          },
          quantity: 1,
        },
      ],
      payment_intent_data: {
        application_fee_amount: applicationFeeAmount,
        transfer_data: {
          destination: practitioner.stripe_connect_account_id,
        },
      },
      customer_email: client_email,
      metadata: {
        practitioner_id: practitioner_id,
        product_id: product.id,
        client_user_id: authData.user.id,
        platform: 'peer-care-connect',
        original_price_id: price_id, // Keep reference for tracking
      },
      success_url: `${Deno.env.get('APP_URL')}/booking/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${Deno.env.get('APP_URL')}/booking/cancel`,
    });

    console.log('[CREATE-CHECKOUT-SESSION] Created session:', session.id);

    // Save checkout session to database for idempotency tracking
    const { error: dbError } = await supabase
      .from('checkout_sessions')
      .insert({
        stripe_checkout_session_id: session.id,
        idempotency_key: idempotencyKey,
        practitioner_id: practitioner_id,
        client_email: client_email,
        client_name: client_name,
        status: 'pending',
        expires_at: new Date(Date.now() + 3600000).toISOString() // 1 hour
      });

    if (dbError) {
      console.error('[CREATE-CHECKOUT-SESSION] Database error (non-fatal):', dbError);
      // Continue even if DB insert fails - session was created successfully
    }

    return new Response(
      JSON.stringify({ 
        checkout_url: session.url,
        session_id: session.id,
        application_fee_amount: applicationFeeAmount,
        practitioner_amount: product.price_amount - applicationFeeAmount
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('[CREATE-CHECKOUT-SESSION] Error:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Failed to create checkout session', 
        details: error.message,
        type: error.type || 'unknown',
        code: error.code || 'unknown'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
}

// Product Management Handlers

async function handleCreateProduct(req: Request, body: any, supabase: any) {
  try {
    const { practitioner_id, name, description, price_amount, duration_minutes, category, service_category } = body;
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    // Create anon key client for user validation
    const supabaseAnon = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );
    
    const token = authHeader.replace('Bearer ', '');
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);
    
    if (authError || !authData?.user?.id) {
      return new Response(JSON.stringify({ error: 'Unauthorized: invalid user' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    if (authData.user.id !== practitioner_id) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', { apiVersion: '2023-10-16' });
    
    // Get practitioner's Connect account
    const { data: practitioner } = await supabase.from('users').select('stripe_connect_account_id').eq('id', practitioner_id).single();
    
    if (!practitioner?.stripe_connect_account_id) {
      return new Response(
        JSON.stringify({ 
          error: 'Practitioner not connected to Stripe',
          requires_connect: true,
          message: 'Please complete Stripe Connect onboarding before creating products'
        }), 
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    // Create product in Stripe on the Connect account
    const stripeProduct = await stripe.products.create({
      name,
      description,
      metadata: { practitioner_id, platform: 'peer-care-connect' },
    }, { stripeAccount: practitioner.stripe_connect_account_id });
    
    // Create price
    const stripePrice = await stripe.prices.create({
      product: stripeProduct.id,
      unit_amount: price_amount,
      currency: 'gbp',
      metadata: { 
        practitioner_id, 
        duration_minutes: duration_minutes?.toString() || '', 
        category: category || 'general',
        service_category: service_category || '', // Add service_category to Stripe metadata for portal alignment
      },
    }, { stripeAccount: practitioner.stripe_connect_account_id });
    
    // Save to database
    const { data: product, error: dbError } = await supabase.from('practitioner_products').insert({
      practitioner_id,
      stripe_product_id: stripeProduct.id,
      stripe_price_id: stripePrice.id,
      name,
      description,
      price_amount,
      duration_minutes,
      category: category || 'general',
      service_category: service_category || null, // Link to product templates and services_offered
      is_active: true,
    }).select().single();
    
    if (dbError) {
      // Cleanup Stripe resources
      await stripe.products.del(stripeProduct.id, { stripeAccount: practitioner.stripe_connect_account_id }).catch(() => {});
      return new Response(JSON.stringify({ error: dbError.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    return new Response(JSON.stringify({ product }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error: any) {
    console.error('[CREATE-PRODUCT] Error:', error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
}

async function handleUpdateProduct(req: Request, body: any, supabase: any) {
  try {
    const { product_id, ...updates } = body;
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    // Create anon key client for user validation
    const supabaseAnon = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );
    
    const token = authHeader.replace('Bearer ', '');
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);
    
    if (authError || !authData?.user?.id) {
      return new Response(JSON.stringify({ error: 'Unauthorized: invalid user' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    const { data: existingProduct } = await supabase.from('practitioner_products').select('*').eq('id', product_id).single();
    
    if (!existingProduct || authData.user.id !== existingProduct.practitioner_id) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', { apiVersion: '2023-10-16' });
    const { data: practitioner } = await supabase.from('users').select('stripe_connect_account_id').eq('id', existingProduct.practitioner_id).single();
    
    if (!practitioner?.stripe_connect_account_id) {
      return new Response(
        JSON.stringify({ 
          error: 'Practitioner not connected to Stripe',
          requires_connect: true,
          message: 'Please complete Stripe Connect onboarding before updating products'
        }), 
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    if (updates.name || updates.description) {
      await stripe.products.update(existingProduct.stripe_product_id, {
        name: updates.name || existingProduct.name,
        description: updates.description || existingProduct.description,
      }, { stripeAccount: practitioner.stripe_connect_account_id });
    }
    
    // Update Stripe price metadata if service_category or other metadata fields changed
    if (updates.service_category !== undefined || updates.category !== undefined || updates.duration_minutes !== undefined) {
      const updatedMetadata: Record<string, string> = {
        practitioner_id: existingProduct.practitioner_id,
        duration_minutes: (updates.duration_minutes ?? existingProduct.duration_minutes)?.toString() || '',
        category: updates.category || existingProduct.category || 'general',
        service_category: updates.service_category || existingProduct.service_category || '',
      };
      
      // Update price metadata (note: Stripe doesn't allow updating price metadata directly)
      // We'd need to create a new price if metadata changes are critical, but for now we'll just update DB
      console.log('[UPDATE-PRODUCT] Metadata would be:', updatedMetadata);
    }
    
    const { data: product, error: dbError } = await supabase.from('practitioner_products').update(updates).eq('id', product_id).select().single();
    
    if (dbError) throw dbError;
    return new Response(JSON.stringify({ product }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error: any) {
    console.error('[UPDATE-PRODUCT] Error:', error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
}

async function handleDeleteProduct(req: Request, body: any, supabase: any) {
  try {
    const { product_id } = body;
    const authHeader = req.headers.get('Authorization');
    
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    // Create anon key client for user validation
    const supabaseAnon = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );
    
    const token = authHeader.replace('Bearer ', '');
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);
    
    if (authError || !authData?.user?.id) {
      return new Response(JSON.stringify({ error: 'Unauthorized: invalid user' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    const { data: existingProduct } = await supabase.from('practitioner_products').select('*').eq('id', product_id).single();
    
    if (!existingProduct || authData.user.id !== existingProduct.practitioner_id) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', { apiVersion: '2023-10-16' });
    const { data: practitioner } = await supabase.from('users').select('stripe_connect_account_id').eq('id', existingProduct.practitioner_id).single();
    
    await stripe.products.update(existingProduct.stripe_product_id, { active: false }, { stripeAccount: practitioner?.stripe_connect_account_id });
    await supabase.from('practitioner_products').delete().eq('id', product_id);
    
    return new Response(JSON.stringify({ success: true }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error: any) {
    console.error('[DELETE-PRODUCT] Error:', error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
}

async function handleListProducts(req: Request, body: any, supabase: any) {
  try {
    const { practitioner_id } = body;
    
    const { data: products, error } = await supabase.from('practitioner_products').select('*').eq('practitioner_id', practitioner_id).order('created_at', { ascending: false });
    
    if (error) throw error;
    return new Response(JSON.stringify({ products: products || [] }), { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error: any) {
    console.error('[LIST-PRODUCTS] Error:', error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
}
